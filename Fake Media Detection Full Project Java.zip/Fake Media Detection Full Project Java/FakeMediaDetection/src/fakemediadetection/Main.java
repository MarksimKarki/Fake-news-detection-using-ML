/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fakemediadetection;

/**
 *
 * @author Elcot
 */
public class Main {
    public static void main(String[] args) throws Exception
    {                          
        MainFrame cf=new MainFrame();
        cf.setTitle("Main Frame");
        cf.setVisible(true);
        cf.setResizable(false);	        
    }
}

